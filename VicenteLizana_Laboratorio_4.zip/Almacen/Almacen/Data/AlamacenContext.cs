﻿using Almacen.Models;
using Microsoft.EntityFrameworkCore;

namespace Almacen.Data
{
    public class AlmacenContext : DbContext
    {
        // Constructor para inyección de dependencias
        public AlmacenContext(DbContextOptions<AlmacenContext> options) : base(options) { }

        // DbSet para la tabla Productos
        public DbSet<Producto> Productos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuración específica para el modelo Producto
            modelBuilder.Entity<Producto>(entity =>
            {
                // Configuración de columnas
                entity.Property(p => p.Nombre)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(p => p.Descripcion)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(p => p.Precio)
                    .HasColumnType("decimal(18,2)");

                entity.Property(p => p.Cantidad)
                    .IsRequired();
            });

        }
    }
}